// ============================================================
// Import to Choice Properties — Popup Script v2.1
// Orion-compatible: handles missing chrome APIs gracefully.
// ============================================================

(async function () {
  try {
    // Query the active tab to see context
    let tab = null;
    try {
      if (chrome.tabs && chrome.tabs.query) {
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        tab = tabs && tabs[0];
      }
    } catch (_) {}

    const isSupportedListing = tab && tab.url && (
      /zillow\.com\/homedetails\//i.test(tab.url) ||
      /realtor\.com\/realestateandhomes-detail\//i.test(tab.url) ||
      /apartments\.com\//i.test(tab.url) ||
      /redfin\.com\/[^/]+\/[^/]+\/[^/]+\/[^/]+\/[^/]+/i.test(tab.url) ||
      /opendoor\.com\/(?:homes|properties|listings)\//i.test(tab.url) ||
      /opendoor\.com\/[^/]+\/[^/]+/i.test(tab.url) ||
      /rentprogress\.com\/(?:houses-for-rent|homes|properties|rental-homes|property-details)\//i.test(tab.url) ||
      /invitationhomes\.com\/(?:property|homes-for-rent|houses-for-rent)\//i.test(tab.url) ||
      /(?:cjproperties\.org|cjrealestate\.com|appfolio\.com)\/[^/]+/i.test(tab.url)
    );

    const countEl   = document.getElementById('session-count');
    const pillEl    = document.getElementById('page-pill');
    const rowEl     = document.getElementById('status-row');
    const tipDef    = document.getElementById('tip-default');
    const tipOn     = document.getElementById('tip-on-listing');
    const queueRow  = document.getElementById('queue-row');
    const queueCount = document.getElementById('queue-count');
    const queueError = document.getElementById('queue-error');
    const flushBtn  = document.getElementById('flush-btn');
    const versionPill = document.getElementById('ext-version-pill');
    const exportBtn = document.getElementById('export-queue-btn');

    // Authoritative installed manifest version
    let installedVersion = '';
    if (chrome.runtime && chrome.runtime.getManifest) {
      try {
        const manifest = chrome.runtime.getManifest();
        if (manifest && manifest.version) {
          installedVersion = manifest.version;
          if (versionPill) versionPill.textContent = 'v' + manifest.version;
        }
      } catch (_) {}
    }

    // Helper for semver comparison
    function isSemverGreater(newer, current) {
      if (!newer || !current) return false;
      const nParts = String(newer).split('.').map(x => parseInt(x, 10) || 0);
      const cParts = String(current).split('.').map(x => parseInt(x, 10) || 0);
      for (let i = 0; i < Math.max(nParts.length, cParts.length); i++) {
        const n = nParts[i] || 0;
        const c = cParts[i] || 0;
        if (n > c) return true;
        if (n < c) return false;
      }
      return false;
    }

    // Live Cloud Check: notify if a newer version is deployed without overwriting the installed version pill
    (async function checkCloudUpdates() {
      try {
        const metaRes = await fetch('https://choice-properties-site.pages.dev/extension-meta.json?_t=' + Date.now(), { cache: 'no-store' });
        if (metaRes.ok) {
          const meta = await metaRes.json();
          if (meta && meta.version && versionPill) {
            if (isSemverGreater(meta.version, installedVersion)) {
              versionPill.title = 'New version v' + meta.version + ' available on site';
              versionPill.style.borderColor = '#f59e0b';
              versionPill.style.color = '#fbbf24';
            } else {
              versionPill.title = 'Choice Properties Extension v' + (installedVersion || meta.version) + ' • Up to date';
            }
          }
        }
      } catch (_) {}
    })();

    // Get session count from badge (fallback to "—" if API not available)
    let count = 0;
    try {
      if (chrome.action && chrome.action.getBadgeText) {
        const badgeText = await chrome.action.getBadgeText({});
        count = parseInt(badgeText, 10) || 0;
      }
    } catch (_) {}
    countEl.textContent = count > 0 ? String(count) : '0';

    // Queue status
    try {
      if (chrome.storage && chrome.storage.local) {
        const data = await chrome.storage.local.get({ cp_queue: [] });
        const queue = data.cp_queue || [];
        if (queue.length > 0) {
          queueRow.style.display = 'flex';
          queueCount.textContent = String(queue.length);
          flushBtn.disabled = false;
          const lastError = queue.map(item => item && item._last_error).filter(Boolean).pop();
          if (queueError && lastError) {
            queueError.textContent = String(lastError).slice(0, 140);
            queueError.style.display = 'block';
          }
        } else {
          queueRow.style.display = 'none';
        }

        flushBtn.addEventListener('click', async () => {
          flushBtn.disabled = true;
          flushBtn.textContent = 'Syncing…';
          try {
            await chrome.runtime.sendMessage({ type: 'FLUSH_QUEUE' });
          } catch (_) {}
          setTimeout(() => window.close(), 800);
        });

        exportBtn?.addEventListener('click', async () => {
          try {
            const latest = await chrome.storage.local.get({ cp_queue: [] });
            const blob = new Blob([JSON.stringify(latest.cp_queue || [], null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = 'choice-properties-import-queue.json';
            link.click();
            setTimeout(() => URL.revokeObjectURL(url), 1000);
          } catch (_) {}
        });
      }
    } catch (_) {}

    if (isSupportedListing) {
      pillEl.textContent = '✓ On supported listing';
      pillEl.className = 'pill';
      rowEl.className = 'status-row on-listing';
      tipDef.style.display = 'none';
      tipOn.style.display  = 'block';
    } else {
      pillEl.textContent = 'Not on listing';
      pillEl.className = 'pill inactive';
    }

    // ── Settings toggles ──────────────────────────────────────
    try {
      let s = { offlineQueue: true };
      if (chrome.storage && chrome.storage.local) {
        const settings = await chrome.storage.local.get({ cp_settings: { offlineQueue: true } });
        s = settings.cp_settings || s;
      }

      const oqToggle = document.getElementById('toggle-queue');
      oqToggle.checked = s.offlineQueue;

      const save = async () => {
        try {
          if (chrome.storage && chrome.storage.local) {
            await chrome.storage.local.set({
              cp_settings: { offlineQueue: oqToggle.checked }
            });
          }
        } catch (_) {}
      };
      oqToggle.addEventListener('change', save);
    } catch (_) {}
  } catch (e) {
    console.warn('[CP Popup]', e);
  }
})();